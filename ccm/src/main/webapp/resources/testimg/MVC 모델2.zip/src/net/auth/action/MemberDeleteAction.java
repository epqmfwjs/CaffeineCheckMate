package net.auth.action;

import java.io.PrintWriter;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.auth.db.AuthDAO;

public class MemberDeleteAction implements Action {
	 public ActionForward execute(HttpServletRequest request,HttpServletResponse response) throws Exception{
		AuthDAO authdao = new AuthDAO();
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("euc-kr");
		
		String id = request.getParameter("var");
		Boolean result = authdao.deleteMember(id);
		
	   	forward.setRedirect(true);
   		forward.setPath("./MemberList.auth");
   		return forward;
	 }
 }

