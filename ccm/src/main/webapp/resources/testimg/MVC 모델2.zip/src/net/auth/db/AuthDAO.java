package net.auth.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class AuthDAO {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public AuthDAO() {
		try{
			Context init = new InitialContext();
	  		DataSource ds = (DataSource) init.lookup("java:comp/env/jdbc/OracleDB");
	  		con = ds.getConnection();
		}catch(Exception ex){
			System.out.println("DB ERROR: " + ex);
			return;
		}
	}
	
	//로그인
	public Boolean memberLogin(String id, String pw){
		String member_login_sql = "SELECT COUNT(id) AS result FROM user_info WHERE id=? AND pw=?";

		try{
			pstmt = con.prepareStatement(member_login_sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				if(rs.getInt(1) == 1) {
					return true;
				}
			}
			
			return false;
			
		}catch(Exception ex){
			System.out.println("getMemberInfo err : " + ex);
		}finally{
			if(rs!=null) try{rs.close();}catch(SQLException ex){}
			if(pstmt!=null) try{pstmt.close();}catch(SQLException ex){}
		}
		return false;
	}
	
	//회원가입
	public Boolean memberJoin(String id, String pw, String email, String name, String birth, String hobby, String intro){
		String member_join_sql = "INSERT INTO user_info values(?, ?, ?, ?, ?, ?, ?)"; //荑쇰━臾�

		try{
			pstmt = con.prepareStatement(member_join_sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, email);
			pstmt.setString(4, name);
			pstmt.setString(5, birth);
			pstmt.setString(6, hobby);
			pstmt.setString(7, intro);
			
			if(pstmt.executeUpdate() != 0){
				return true;
			}
			return false;

		}catch(Exception ex){
			System.out.println("MemberJoin err : " + ex);
		}finally{
			if(rs!=null) try{rs.close();}catch(SQLException ex){}
			if(pstmt!=null) try{pstmt.close();}catch(SQLException ex){}
		}
		return null;
	}
	
	//DB 유저 가져옴
	public List getMemberList(){
		String member_list_sql="SELECT * FROM user_info";
		
		List list = new ArrayList();

		try{
			pstmt = con.prepareStatement(member_list_sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				AuthBean member = new AuthBean();
				if(!rs.getString("ID").equals("admin")) {
					member.setID(rs.getString("ID"));
					member.setPW(rs.getString("PW"));
					member.setEMAIL(rs.getString("EMAIL"));
					member.setNAME(rs.getString("NAME"));
					member.setBIRTH(rs.getString("BIRTH"));
					member.setHOBBY(rs.getString("HOBBY"));
					member.setINTRO(rs.getString("INTRO"));
					list.add(member);
				}
			}
			return list;
		}catch(Exception ex){
			System.out.println("getMemberList err : " + ex);
		}finally{
			if(rs!=null) try{rs.close();}catch(SQLException ex){}
			if(pstmt!=null) try{pstmt.close();}catch(SQLException ex){}
		}
		return null;
	}
	
	// 유저 상세정보
	public List getMemberInfo(String id){
		String member_info_sql="SELECT * FROM user_info WHERE ID = ?";
		List list = new ArrayList();

		try{
			pstmt = con.prepareStatement(member_info_sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				AuthBean member = new AuthBean();
				member.setID(rs.getString("ID"));
				member.setPW(rs.getString("PW"));
				member.setEMAIL(rs.getString("EMAIL"));
				member.setNAME(rs.getString("NAME"));
				member.setBIRTH(rs.getString("BIRTH"));
				member.setHOBBY(rs.getString("HOBBY"));
				member.setINTRO(rs.getString("INTRO"));
				list.add(member);
			}
			return list;
			
		}catch(Exception ex){
			System.out.println("getMemberInfo err : " + ex);
		}finally{
			if(rs!=null) try{rs.close();}catch(SQLException ex){}
			if(pstmt!=null) try{pstmt.close();}catch(SQLException ex){}
		}
		return null;
	}
	
	// 유저 삭제
	public boolean deleteMember(String id){
		String member_delete_sql="DELETE FROM user_info WHERE ID=?";
		int result = 0;

		try{
			//�뼱�뱶誘쇱� �젣嫄� x
			if(!id.equals("admin")) {
				pstmt=con.prepareStatement(member_delete_sql);
				pstmt.setString(1, id);
				result=pstmt.executeUpdate();
			}
			if(result==0) {
				return false;
			}
			return true;
			
		} catch(Exception ex){
			System.out.println("boardDelete �뿉�윭 : "+ex);
		} finally{
			try{
				if(pstmt!=null)pstmt.close();
			}catch(Exception ex) {}
		}
		
		return false;
	}
}
	