package net.auth.action;

import java.io.PrintWriter;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.auth.db.AuthDAO;

public class MemberJoinAction implements Action {
	 public ActionForward execute(HttpServletRequest request,HttpServletResponse response) throws Exception{
		AuthDAO authdao = new AuthDAO();
		ActionForward forward= new ActionForward();
		
		request.setCharacterEncoding("UTF-8");
		
		//Params
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String email = request.getParameter("mail");
		String name = request.getParameter("name");
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		String day = request.getParameter("day");
		String intro = request.getParameter("intro");
		
		//�������
		String birth = ""+year+"-"+month+"-"+day;

		//üũ�ڽ�
		String[] temp = request.getParameterValues("hobby");
		String hobby = Arrays.toString(temp);
		
		System.out.println("�̸�:"+name);
		
		Boolean memberJoin = authdao.memberJoin(id, pw, email, name, birth, hobby, intro);

		forward.setRedirect(true);
   		forward.setPath("./board/login.jsp");
   		return forward;
	 }
 }

