package net.auth.action;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.auth.db.AuthDAO;

public class MemberViewAction implements Action {
	 public ActionForward execute(HttpServletRequest request,HttpServletResponse response) throws Exception{
		AuthDAO authdao = new AuthDAO();
		List memberinfo = new ArrayList();

		request.setCharacterEncoding("euc-kr");
		String id = request.getParameter("var");
		System.out.println(id);
		memberinfo = authdao.getMemberInfo(id);
		
   		request.setAttribute("memberinfo", memberinfo);
   		
		ActionForward forward= new ActionForward();
	   	forward.setRedirect(false);
   		forward.setPath("./board/member_view.jsp");
   		return forward;
	 }
 }

