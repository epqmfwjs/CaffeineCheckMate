package net.auth.action;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.auth.db.AuthDAO;
import net.board.db.BoardDAO;


public class MemberListAction implements Action {
	 public ActionForward execute(HttpServletRequest request,HttpServletResponse response) throws Exception{
		AuthDAO authdao = new AuthDAO();
		List memberlist = new ArrayList();
		
		memberlist = authdao.getMemberList(); //����Ʈ�� �޾ƿ�.
		
   		request.setAttribute("memberlist", memberlist);
		
		ActionForward forward= new ActionForward();
	   	forward.setRedirect(false);
   		forward.setPath("./board/member_list.jsp");
   		return forward;
	 }
 }