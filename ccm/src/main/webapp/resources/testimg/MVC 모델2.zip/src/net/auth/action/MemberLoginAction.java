package net.auth.action;

import java.io.PrintWriter;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.auth.db.AuthDAO;

public class MemberLoginAction implements Action {
	 public ActionForward execute(HttpServletRequest request,HttpServletResponse response) throws Exception{
		AuthDAO authdao = new AuthDAO();
		ActionForward forward= new ActionForward();
		HttpSession session = request.getSession();

		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		Boolean memberLogin = authdao.memberLogin(id, pw);
		System.out.println(memberLogin);
		
		if(memberLogin == false){
			forward.setRedirect(true);
	   		forward.setPath("/Login.auth");
	   		return forward;
	   	}

		session.setAttribute("login", memberLogin);
		session.setAttribute("id", id);

		if(memberLogin && id.equals("admin")){
	   		//���� �α���
		   	forward.setRedirect(true);
	   		forward.setPath("/MemberList.auth");
	   		return forward;
	   		
	   	} else {
	   		forward.setRedirect(true);
	   		forward.setPath("/BoardList.bo");
	   		return forward;
	   	}
		
	 }
 }

